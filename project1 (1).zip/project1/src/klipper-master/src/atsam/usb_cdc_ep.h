#ifndef __SAM3_USB_CDC_EP_H
#define __SAM3_USB_CDC_EP_H

enum {
    USB_CDC_EP_ACM = 3,
    USB_CDC_EP_BULK_OUT = 1,
    USB_CDC_EP_BULK_IN = 2,
};

#endif // usb_cdc_ep.h
