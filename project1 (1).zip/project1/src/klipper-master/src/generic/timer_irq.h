#ifndef __GENERIC_TIMER_IRQ_H
#define __GENERIC_TIMER_IRQ_H

uint32_t timer_dispatch_many(void);

#endif // timer_irq.h
